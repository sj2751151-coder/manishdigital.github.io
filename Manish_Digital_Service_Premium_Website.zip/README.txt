MANISH DIGITAL SERVICE — PREMIUM GITHUB PAGES WEBSITE

FILES
- index.html: homepage
- styles.css: responsive dark-blue theme
- one HTML file per service: individual service detail pages

BEFORE PUBLISHING
1. In every HTML file, replace https://wa.me/91YOURNUMBER with your WhatsApp number in international format, digits only after / (India example: 91 followed by your 10-digit mobile number).
2. Replace YOUR_EMAIL@example.com with the email address you want customers to use.
3. Keep index.html and styles.css in the repository root. Upload all HTML files to the same root.
4. GitHub repository: manishdigitalservice.github.io
5. Open the repository, choose Add file > Upload files, upload/drag all files from this folder, then Commit changes to the main branch.
6. Wait briefly, then open https://manishdigitalservice.github.io

No build tools, paid hosting, JavaScript frameworks, or external libraries are required.
The contact buttons contain placeholders until you replace the phone/email.
