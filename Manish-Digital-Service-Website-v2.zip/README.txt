MANISH DIGITAL SERVICE

1. index.html ko browser mein open karke website dekhein.
2. index.html mein XXXXXXXXXX ko apne 10-digit mobile number se replace karein.
3. Free hosting par upload karke website live ki ja sakti hai.

Note: Contact number jaan-bujhkar placeholder rakha gaya hai.
